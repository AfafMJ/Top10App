package com.afaf.top10app

class App (val title: String)